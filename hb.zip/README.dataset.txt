# Fabric Defect V2 > 2024-06-26 7:00am
https://universe.roboflow.com/projectsenes/fabric-defect-v2-vaycc

Provided by a Roboflow user
License: CC BY 4.0

