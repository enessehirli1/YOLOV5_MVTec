# Fabric Defect > 2024-06-26 12:25pm
https://universe.roboflow.com/projectsenes/fabric-defect-kx5ua

Provided by a Roboflow user
License: CC BY 4.0

