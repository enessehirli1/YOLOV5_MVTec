# Fabric Defect V2 > 2024-06-26 8:23am
https://universe.roboflow.com/projectsenes/fabric-defect-v2-vaycc

Provided by a Roboflow user
License: CC BY 4.0

